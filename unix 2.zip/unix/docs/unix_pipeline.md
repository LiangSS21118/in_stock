# Unix Pipeline Notes

This project requires an Ubuntu Docker container and a BusyBox CGI server.
Opening `code_artifact.html` directly can display the interface, but cannot start a battle.

## Required Runtime Flow

Camera -> Gesture -> BusyBox CGI -> Shell Script -> JSON -> HTML Canvas

## Shell Endpoints

- `cgi-bin/health.sh`: confirms that the Unix engine is available
- `cgi-bin/start_game.sh`: creates the JSON state for the selected character
- `cgi-bin/next_action.sh`: uses `/dev/urandom` and `date +%s` to create a Boss action and deadline
- `cgi-bin/resolve_turn.sh`: calls the pipeline, updates HP, score, wave, and JSON state

## Unix Concepts Used

- Shell arguments: `$1`, `$2`, and default values
- Conditional logic: `if`, `elif`, `case`, and `fi`
- Integer arithmetic: `$(( ... ))`
- Executable permission: `chmod +x`
- Standard output: `printf`
- Pipeline: `|`
- File output and passthrough: `tee`, `cat`
- JSON state updates: `jq`
- Log append: `>>`
- Epoch deadline: `date +%s`
- Random Boss action: `/dev/urandom`
- Single-player state lock: `mkdir`

## Run

```sh
docker build -t escape-zoo-unix .
docker run --rm -p 8080:80 --name escape-zoo escape-zoo-unix
```

Open `http://localhost:8080`.
