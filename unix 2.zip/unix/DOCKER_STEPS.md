# Docker 執行說明

本專題必須透過 Ubuntu Docker 容器啟動。容器內使用 BusyBox `httpd` 提供靜態網頁與 Shell CGI。

## 建置 Image

請在終端機執行：

```sh
cd ~/Desktop/unix
docker build -t escape-zoo-unix .
```

## 啟動遊戲

```sh
docker run --rm -p 8080:80 --name escape-zoo escape-zoo-unix
```

瀏覽器開啟：

```text
http://localhost:8080
```

## 確認 Unix CGI 引擎

另開一個終端機執行：

```sh
curl http://localhost:8080/cgi-bin/health.sh
docker exec escape-zoo tail -n 20 /var/www/html/logs/system.log
docker exec escape-zoo cat /var/www/html/data/battle_db.json
```

直接雙擊 `code_artifact.html` 只能看到介面。因為無法連線到 BusyBox CGI，正式對戰不會開始。

## 停止

```sh
Ctrl + C
```
