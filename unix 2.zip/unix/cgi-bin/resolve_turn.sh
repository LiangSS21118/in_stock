#!/bin/sh

. "${PROJECT_ROOT:-/var/www/html}/scripts/common.sh"

require_state
lock_state || {
  json_header
  printf '{"ok":false,"error":"ENGINE_BUSY"}\n'
  exit 0
}

gesture="$(query_value gesture)"
case "$gesture" in
  PAPER|ROCK|SCISSORS|TIMEOUT) ;;
  *) gesture="TIMEOUT" ;;
esac

status="$(jq -r '.battle_record.status' "$STATE_FILE")"
if [ "$status" != "AWAITING_GESTURE" ]; then
  json_header
  jq -c '{ok:false,error:"NO_ACTIVE_BOSS_ACTION",battle_record:.battle_record}' "$STATE_FILE"
  exit 0
fi

now="$(date +%s)"
deadline="$(jq -r '.battle_record.deadline_epoch' "$STATE_FILE")"
if [ "$now" -gt "$deadline" ]; then gesture="TIMEOUT"; fi

action="$(jq -r '.battle_record.boss_action' "$STATE_FILE")"
wave="$(jq -r '.battle_record.wave_round' "$STATE_FILE")"
score="$(jq -r '.battle_record.score' "$STATE_FILE")"
player_hp="$(jq -r '.battle_record.player_hp' "$STATE_FILE")"
player_max_hp="$(jq -r '.battle_record.player_max_hp' "$STATE_FILE")"
player_atk="$(jq -r '.battle_record.player_atk' "$STATE_FILE")"
boss_hp="$(jq -r '.battle_record.boss_hp' "$STATE_FILE")"
boss_max_hp="$(jq -r '.battle_record.boss_max_hp' "$STATE_FILE")"
boss_attack_damage="$(jq -r '.battle_record.boss_attack_damage' "$STATE_FILE")"

turn_json="$(PROJECT_ROOT="$PROJECT_ROOT" sh "$PROJECT_ROOT/scripts/run_pipeline.sh" \
  "$gesture" "$action" "$wave" "$player_max_hp" "$player_atk" "$boss_attack_damage")"

result="$(printf '%s' "$turn_json" | jq -r '.result')"
damage_to_boss="$(printf '%s' "$turn_json" | jq -r '.damage_to_boss')"
damage_to_player="$(printf '%s' "$turn_json" | jq -r '.damage_to_player')"
heal_to_player="$(printf '%s' "$turn_json" | jq -r '.heal_to_player')"
score_reward="$(printf '%s' "$turn_json" | jq -r '.score_reward')"

score=$((score + score_reward))
player_hp=$((player_hp - damage_to_player + heal_to_player))
if [ "$player_hp" -gt "$player_max_hp" ]; then player_hp="$player_max_hp"; fi
if [ "$player_hp" -lt 0 ]; then player_hp=0; fi
boss_hp=$((boss_hp - damage_to_boss))
if [ "$boss_hp" -lt 0 ]; then boss_hp=0; fi

next_status="ACTIVE"
if [ "$boss_hp" -le 0 ]; then
  if [ "$wave" -ge 3 ]; then
    next_status="VICTORY"
  else
    wave=$((wave + 1))
    boss_max_hp=$((boss_max_hp * 112 / 100))
    boss_hp="$boss_max_hp"
    next_status="WAVE_CLEAR"
  fi
elif [ "$player_hp" -le 0 ]; then
  next_status="GAME_OVER"
fi

jq \
  --arg result "$result" \
  --arg gesture "$gesture" \
  --arg action "$action" \
  --arg status "$next_status" \
  --argjson wave "$wave" \
  --argjson score "$score" \
  --argjson player_hp "$player_hp" \
  --argjson boss_hp "$boss_hp" \
  --argjson boss_max_hp "$boss_max_hp" \
  --argjson damage_to_player "$damage_to_player" \
  --argjson heal_to_player "$heal_to_player" \
  --argjson damage_to_boss "$damage_to_boss" \
  --argjson now "$now" \
  '.battle_record.wave_round = $wave
   | .battle_record.score = $score
   | .battle_record.player_hp = $player_hp
   | .battle_record.boss_hp = $boss_hp
   | .battle_record.boss_max_hp = $boss_max_hp
   | .battle_record.boss_action = "WAIT"
   | .battle_record.deadline_epoch = 0
   | .battle_record.status = $status
   | .battle_record.last_result = $result
   | .battle_record.last_player_action = $gesture
   | .battle_record.last_boss_action = $action
   | .battle_record.damage_to_player = $damage_to_player
   | .battle_record.heal_to_player = $heal_to_player
   | .battle_record.damage_to_boss = $damage_to_boss
   | .battle_record.updated_epoch = $now' \
  "$STATE_FILE" | write_state

log_event "[TURN] wave=$wave gesture=$gesture boss=$action result=$result player_hp=$player_hp boss_hp=$boss_hp score=$score status=$next_status"
json_header
jq -cn --argjson turn "$turn_json" --slurpfile state "$STATE_FILE" \
  '{ok:true,turn:$turn,battle_record:$state[0].battle_record}'
