#!/bin/sh

. "${PROJECT_ROOT:-/var/www/html}/scripts/common.sh"

character="$(query_value character)"
case "$character" in
  bear)
    character_name="棕熊"
    player_hp=180
    player_atk=26
    ;;
  tiger)
    character_name="老虎"
    player_hp=135
    player_atk=36
    ;;
  penguin)
    character_name="企鵝"
    player_hp=115
    player_atk=42
    ;;
  *)
    json_header
    printf '{"ok":false,"error":"INVALID_CHARACTER"}\n'
    exit 0
    ;;
esac

lock_state || {
  json_header
  printf '{"ok":false,"error":"ENGINE_BUSY"}\n'
  exit 0
}

now="$(date +%s)"
jq -n \
  --arg character_id "$character" \
  --arg character "$character_name" \
  --argjson player_hp "$player_hp" \
  --argjson player_atk "$player_atk" \
  --argjson now "$now" \
  '{
    system: {
      os: "Ubuntu BusyBox CGI",
      status: "HEALTHY",
      version: "v4.0-unix-required"
    },
    battle_record: {
      character_id: $character_id,
      character: $character,
      wave_round: 1,
      max_wave: 3,
      score: 0,
      player_hp: $player_hp,
      player_max_hp: $player_hp,
      player_atk: $player_atk,
      boss_hp: 150,
      boss_max_hp: 150,
      boss_attack_damage: 15,
      boss_action: "WAIT",
      deadline_epoch: 0,
      reaction_seconds: 5,
      status: "READY",
      last_result: "NONE",
      last_player_action: "NONE",
      last_boss_action: "NONE",
      damage_to_player: 0,
      heal_to_player: 0,
      damage_to_boss: 0,
      updated_epoch: $now
    }
  }' | write_state

log_event "[START] character=$character_name hp=$player_hp atk=$player_atk"
json_header
jq -c '{ok:true,battle_record:.battle_record}' "$STATE_FILE"
