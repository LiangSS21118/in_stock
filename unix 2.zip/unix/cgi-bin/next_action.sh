#!/bin/sh

. "${PROJECT_ROOT:-/var/www/html}/scripts/common.sh"

require_state
lock_state || {
  json_header
  printf '{"ok":false,"error":"ENGINE_BUSY"}\n'
  exit 0
}

status="$(jq -r '.battle_record.status' "$STATE_FILE")"
case "$status" in
  VICTORY|GAME_OVER)
    json_header
    jq -c --arg error "$status" '{ok:false,error:$error,battle_record:.battle_record}' "$STATE_FILE"
    exit 0
    ;;
esac

wave="$(jq -r '.battle_record.wave_round' "$STATE_FILE")"
seconds="$(reaction_seconds "$wave")"
now="$(date +%s)"
deadline=$((now + seconds))
random_byte="$(od -An -N1 -tu1 /dev/urandom | tr -d ' ')"
action_index=$((random_byte % 3))
last_action="$(jq -r '.battle_record.last_boss_action' "$STATE_FILE")"
case "$last_action" in
  ATTACK) last_action_index=0 ;;
  DEFEND) last_action_index=1 ;;
  SPECIAL) last_action_index=2 ;;
  *) last_action_index=-1 ;;
esac

# Keep the move random while preventing long streaks that feel like a fixed Boss pattern.
if [ "$action_index" -eq "$last_action_index" ]; then
  action_index=$(( (action_index + 1 + (random_byte / 3 % 2)) % 3 ))
fi

case "$action_index" in
  0) action="ATTACK" ;;
  1) action="DEFEND" ;;
  *) action="SPECIAL" ;;
esac

jq \
  --arg action "$action" \
  --argjson seconds "$seconds" \
  --argjson deadline "$deadline" \
  --argjson now "$now" \
  '.battle_record.boss_action = $action
   | .battle_record.reaction_seconds = $seconds
   | .battle_record.deadline_epoch = $deadline
   | .battle_record.status = "AWAITING_GESTURE"
   | .battle_record.updated_epoch = $now' \
  "$STATE_FILE" | write_state

log_event "[BOSS] wave=$wave action=$action deadline=$deadline"
json_header
jq -c '{ok:true,battle_record:.battle_record}' "$STATE_FILE"
