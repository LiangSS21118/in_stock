#!/bin/sh
# Unix Shell battle resolver.
# Usage: sh scripts/battle.sh GESTURE BOSS_ACTION ROUND PLAYER_MAX_HP PLAYER_ATK BOSS_ATTACK_DAMAGE

PLAYER_GESTURE="${1:-TIMEOUT}"
BOSS_ACTION="${2:-ATTACK}"
ROUND="${3:-1}"
PLAYER_MAX_HP="${4:-180}"
BASE_DAMAGE="${5:-26}"
BOSS_ATTACK_DAMAGE="${6:-15}"

DAMAGE_TO_BOSS=0
DAMAGE_TO_PLAYER=0
HEAL_TO_PLAYER=0
RESULT="HIT"
SCORE_REWARD=0

if [ "$PLAYER_GESTURE" = "TIMEOUT" ]; then
  RESULT="TIMEOUT"
  DAMAGE_TO_PLAYER=$BOSS_ATTACK_DAMAGE
  if [ "$ROUND" -ge 3 ]; then
    DAMAGE_TO_PLAYER=$((DAMAGE_TO_PLAYER * 16 / 10))
  fi
  if [ "$BOSS_ACTION" = "SPECIAL" ]; then
    if [ "$ROUND" -ge 3 ]; then
      DAMAGE_TO_PLAYER=50
    else
      DAMAGE_TO_PLAYER=$(( (PLAYER_MAX_HP + 2) / 3 ))
    fi
  fi
elif [ "$BOSS_ACTION" = "ATTACK" ]; then
  if [ "$PLAYER_GESTURE" = "PAPER" ]; then
    RESULT="BLOCK_SUCCESS"
    HEAL_TO_PLAYER=$(( (PLAYER_MAX_HP * 5 + 99) / 100 ))
    if [ "$HEAL_TO_PLAYER" -gt 8 ]; then HEAL_TO_PLAYER=8; fi
    SCORE_REWARD=150
  else
    DAMAGE_TO_PLAYER=$BOSS_ATTACK_DAMAGE
    if [ "$ROUND" -ge 3 ]; then
      DAMAGE_TO_PLAYER=$((DAMAGE_TO_PLAYER * 16 / 10))
    fi
  fi
elif [ "$BOSS_ACTION" = "DEFEND" ]; then
  if [ "$PLAYER_GESTURE" = "ROCK" ]; then
    RESULT="BREAK_SUCCESS"
    DAMAGE_TO_BOSS=$((BASE_DAMAGE * 3 / 2))
    SCORE_REWARD=250
  else
    RESULT="BLOCKED"
  fi
elif [ "$BOSS_ACTION" = "SPECIAL" ]; then
  if [ "$PLAYER_GESTURE" = "SCISSORS" ]; then
    RESULT="INTERRUPT_SUCCESS"
    DAMAGE_TO_BOSS=$((BASE_DAMAGE * 18 / 10))
    SCORE_REWARD=400
  else
    if [ "$ROUND" -ge 3 ]; then
      DAMAGE_TO_PLAYER=50
    else
      DAMAGE_TO_PLAYER=$(( (PLAYER_MAX_HP + 2) / 3 ))
    fi
  fi
fi

printf '{"result":"%s","damage_to_boss":%s,"damage_to_player":%s,"heal_to_player":%s,"score_reward":%s}\n' \
  "$RESULT" "$DAMAGE_TO_BOSS" "$DAMAGE_TO_PLAYER" "$HEAL_TO_PLAYER" "$SCORE_REWARD"
