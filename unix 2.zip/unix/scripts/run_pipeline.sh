#!/bin/sh
# Camera -> Gesture -> Shell Script -> JSON -> HTML Canvas.
# Usage: sh scripts/run_pipeline.sh GESTURE BOSS_ACTION ROUND PLAYER_MAX_HP PLAYER_ATK BOSS_ATTACK_DAMAGE

PROJECT_ROOT="${PROJECT_ROOT:-/var/www/html}"
GESTURE="${1:-TIMEOUT}"
BOSS_ACTION="${2:-ATTACK}"
ROUND="${3:-1}"
PLAYER_MAX_HP="${4:-180}"
PLAYER_ATK="${5:-26}"
BOSS_ATTACK_DAMAGE="${6:-15}"
DB_PATH="$PROJECT_ROOT/data/turn_result.json"
LOG_PATH="$PROJECT_ROOT/logs/system.log"

mkdir -p "$PROJECT_ROOT/data" "$PROJECT_ROOT/logs"
chmod +x "$PROJECT_ROOT/scripts/battle.sh"

printf '[%s] [PIPE] Camera -> Gesture(%s) -> Shell Script -> JSON -> HTML Canvas\n' \
  "$(date '+%Y-%m-%d %H:%M:%S')" "$GESTURE" >> "$LOG_PATH"

sh "$PROJECT_ROOT/scripts/battle.sh" \
  "$GESTURE" "$BOSS_ACTION" "$ROUND" "$PLAYER_MAX_HP" "$PLAYER_ATK" "$BOSS_ATTACK_DAMAGE" \
  | tee "$DB_PATH" \
  | cat
