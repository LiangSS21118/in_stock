#!/bin/sh

PROJECT_ROOT="${PROJECT_ROOT:-/var/www/html}"
STATE_FILE="$PROJECT_ROOT/data/battle_db.json"
LOG_FILE="$PROJECT_ROOT/logs/system.log"
LOCK_DIR="/tmp/escape-zoo.lock"

json_header() {
  printf 'Content-Type: application/json\r\n'
  printf 'Cache-Control: no-store\r\n'
  printf '\r\n'
}

query_value() {
  printf '%s' "${QUERY_STRING:-}" \
    | tr '&' '\n' \
    | sed -n "s/^$1=//p" \
    | head -n 1
}

log_event() {
  mkdir -p "$PROJECT_ROOT/logs"
  printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG_FILE"
}

lock_state() {
  tries=0
  while ! mkdir "$LOCK_DIR" 2>/dev/null; do
    tries=$((tries + 1))
    if [ "$tries" -gt 50 ]; then
      return 1
    fi
    sleep 0.02
  done
  trap 'rmdir "$LOCK_DIR" 2>/dev/null' EXIT INT TERM
}

write_state() {
  mkdir -p "$PROJECT_ROOT/data"
  tmp_file="$(mktemp "$PROJECT_ROOT/data/battle_db.XXXXXX")"
  cat > "$tmp_file"
  mv "$tmp_file" "$STATE_FILE"
}

require_state() {
  if [ ! -s "$STATE_FILE" ]; then
    json_header
    printf '{"ok":false,"error":"GAME_NOT_STARTED"}\n'
    exit 0
  fi
}

reaction_seconds() {
  if [ "$1" -eq 1 ]; then
    printf '5'
  else
    printf '3'
  fi
}
